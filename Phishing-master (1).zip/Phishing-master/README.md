# Phishing on Course Web

How to set up in phishing site in localy

For windows User

1) Download wamp server and install to your pc. Below link has how can install the wamp in the windows.
    http://www.c-sharpcorner.com/UploadFile/47548d/how-to-install-wamp-server-on-windows-8-1/

2) Download all the files in the repository and put in the wamp server www folder
      eg:- I'm installed to wamp in the c drive. So it's path like C:\wamp64\www
      
3) Turn on your wamp server (if wamp server run correctly it'll be show green image)

4) Open your web browser and go to the localhost (Type the ULR Localhost. then it will be show files what we downloaded)

5) Access the login page using localhost/[filename]/login.html
  then it will be show you to courseweb login page.
  
  This is my blog post about phishing 
    http://chathurangasineth.blogspot.com/2017/03/phishing_23.html
